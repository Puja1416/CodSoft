# 🧮 Calculator App in Python

A simple calculator application built using Python. This project helps you perform basic arithmetic operations such as addition, subtraction, multiplication, and division. It is a great beginner-level project to understand Python syntax, functions.

## 📌 Features

- Addition
- Subtraction
- Multiplication
- Division
- User input validation


## 💻 Technologies Used

- Python 3.x

## Installation

  [Download Python](https://www.python.org/downloads/)
  
##  Run the application:


python Calculator_1.py



